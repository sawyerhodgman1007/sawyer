GuessWho
===========
C# console application to test different strategies for the game Guess Who.